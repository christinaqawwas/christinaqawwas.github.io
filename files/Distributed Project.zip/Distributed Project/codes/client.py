import socket
import tkinter as tk
from tkinter import messagebox

# Function to send query to server
def query_server():
    word = entry.get().strip()
    if not word:
        messagebox.showwarning("Input Error", "Please enter a word.")
        return

    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect(("127.0.0.1", 8080))  # Connect to the server at port 8080
        client.send(word.encode())

        response = client.recv(1024).decode()
        result_label.config(text=response)
        client.close()
    except Exception as e:
        messagebox.showerror("Connection Error", f"Failed to connect to server: {e}")

# Function to clear the search field and result label
def clear_fields():
    entry.delete(0, tk.END)  # Clears the entry field
    result_label.config(text="")  # Clears the result label

# Function to quit the application
def quit_application():
    root.quit()

# GUI setup
root = tk.Tk()
root.title("Dictionary Client")

tk.Label(root, text="Enter a word:").pack()
entry = tk.Entry(root)
entry.pack()

tk.Button(root, text="Search", command=query_server).pack()
tk.Button(root, text="Clear", command=clear_fields).pack()  # Clear button
tk.Button(root, text="Quit", command=quit_application).pack()  # Quit button
result_label = tk.Label(root, text="", fg="blue")
result_label.pack()

root.mainloop()