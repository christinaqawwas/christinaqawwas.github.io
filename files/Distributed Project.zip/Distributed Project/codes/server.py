import socket
import threading

# Load dictionary data
def load_dictionary(file_path):
    dictionary = {}
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            for line in file:
                parts = line.strip().split(':', 1)  # Ensure correct splitting
                if len(parts) == 2:  # Check for valid format
                    word, meaning = parts
                    dictionary[word.lower()] = meaning
                else:
                    # Skipping invalid lines
                    pass
        
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
    except Exception as e:
        print(f"Unexpected error while loading dictionary: {e}")

    return dictionary

# Load dictionary from file
dictionary = load_dictionary("dictionary.txt")

# Handle each client request
def handle_client(client_socket):
    try:
        while True:
            word = client_socket.recv(1024).decode().strip().lower()
            if not word:
                break
            response = dictionary.get(word, "Error: Word not found!")
            client_socket.send(response.encode())
    except Exception as e:
        print(f"Error with client connection: {e}")
    finally:
        client_socket.close()

# Start the server
def start_server(host="0.0.0.0", port=8080):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))
    server.listen(5)  # Allow up to 5 clients at once
    print(f"Server running on {host}:{port}")

    while True:
        client_socket, addr = server.accept()
        print(f"Connection established with {addr}")
        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.start()

if __name__ == "__main__":
    start_server()